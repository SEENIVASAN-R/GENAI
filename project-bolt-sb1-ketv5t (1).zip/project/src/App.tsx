import React, { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { QuestionInput } from './components/QuestionInput';
import { Answer } from './components/Answer';
import { FileText } from 'lucide-react';
import type { FileContent, QAState } from './types';
import { generateAnswer } from './utils/textProcessing';

function App() {
  const [fileContent, setFileContent] = useState<FileContent | null>(null);
  const [qaState, setQAState] = useState<QAState>({
    question: '',
    answer: null,
    isLoading: false,
    error: null,
  });

  const handleFileProcess = (text: string, fileName: string, fileType: string) => {
    setFileContent({ text, fileName, fileType });
    setQAState({
      question: '',
      answer: null,
      isLoading: false,
      error: null,
    });
  };

  const handleAskQuestion = async (question: string) => {
    if (!fileContent) {
      setQAState({
        ...qaState,
        error: 'Please upload a document first',
        isLoading: false,
      });
      return;
    }

    setQAState({
      ...qaState,
      isLoading: true,
      error: null,
    });

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const answer = generateAnswer(question, fileContent.text);
      
      setQAState({
        question,
        answer,
        isLoading: false,
        error: null,
      });
    } catch (error) {
      setQAState({
        ...qaState,
        error: 'Failed to generate answer',
        isLoading: false,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center justify-center gap-2">
            <FileText className="h-8 w-8 text-blue-500" />
            Document Q&A System
          </h1>
          <p className="mt-2 text-gray-600">
            Upload a document and ask questions about its content
          </p>
        </div>

        {!fileContent ? (
          <FileUpload onFileProcess={handleFileProcess} />
        ) : (
          <div className="space-y-6">
            <div className="bg-white p-4 rounded-lg shadow flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-900">{fileContent.fileName}</h3>
                <p className="text-sm text-gray-500">Document loaded and ready for questions</p>
              </div>
              <button
                onClick={() => setFileContent(null)}
                className="text-sm text-red-500 hover:text-red-600"
              >
                Remove
              </button>
            </div>

            <QuestionInput onAsk={handleAskQuestion} isLoading={qaState.isLoading} />

            {(qaState.answer || qaState.error || qaState.isLoading) && (
              <div className="bg-gray-50 p-6 rounded-lg">
                <h3 className="text-sm font-medium text-gray-900 mb-4">Answer</h3>
                <Answer
                  answer={qaState.answer}
                  error={qaState.error}
                  isLoading={qaState.isLoading}
                />
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export default App;