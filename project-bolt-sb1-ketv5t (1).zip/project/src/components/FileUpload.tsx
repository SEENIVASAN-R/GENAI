import React, { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload } from 'lucide-react';

interface FileUploadProps {
  onFileProcess: (content: string, fileName: string, fileType: string) => void;
}

export function FileUpload({ onFileProcess }: FileUploadProps) {
  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target?.result as string;
      onFileProcess(text, file.name, file.type);
    };
    reader.readAsText(file);
  }, [onFileProcess]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop });

  return (
    <div
      {...getRootProps()}
      className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
    >
      <input {...getInputProps()} />
      <Upload className="mx-auto h-12 w-12 text-gray-400" />
      <p className="mt-4 text-lg text-gray-600">
        {isDragActive
          ? "Drop the file here..."
          : "Drag & drop a file here, or click to select"}
      </p>
      <p className="mt-2 text-sm text-gray-500">
        Supports PDF, DOCX, PPT, and TXT files
      </p>
    </div>
  );
}