export async function extractTextFromFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        resolve(text);
      } catch (error) {
        reject(new Error('Failed to extract text from file'));
      }
    };
    
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}

export function generateAnswer(question: string, context: string): string {
  // This is a simple implementation. In a production environment,
  // you would want to use a proper NLP model or API
  const relevantContent = context.split('\n')
    .filter(line => line.toLowerCase().includes(question.toLowerCase()))
    .join('\n');

  return relevantContent || 'I could not find a relevant answer in the provided document.';
}