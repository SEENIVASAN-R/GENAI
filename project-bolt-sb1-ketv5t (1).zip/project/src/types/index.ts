export interface FileContent {
  text: string;
  fileName: string;
  fileType: string;
}

export interface QAState {
  question: string;
  answer: string | null;
  isLoading: boolean;
  error: string | null;
}